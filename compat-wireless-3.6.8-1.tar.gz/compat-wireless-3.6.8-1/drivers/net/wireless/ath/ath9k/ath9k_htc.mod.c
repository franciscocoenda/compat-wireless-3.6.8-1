#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x8495e121, "module_layout" },
	{ 0x7a26d1b6, "ath9k_hw_set_txq_props" },
	{ 0x408d2ce, "ath9k_hw_init" },
	{ 0xc6d08280, "kmalloc_caches" },
	{ 0xd6c7afb9, "ath9k_hw_deinit" },
	{ 0x5a5e7ea3, "simple_read_from_buffer" },
	{ 0xfbb518ae, "ath9k_hw_cfg_output" },
	{ 0x1e9eb9dc, "debugfs_create_dir" },
	{ 0xadaabe1b, "pv_lock_ops" },
	{ 0x3ec8886f, "param_ops_int" },
	{ 0xbab754dd, "device_release_driver" },
	{ 0x8281e0cb, "ath9k_hw_set_gpio" },
	{ 0xe0b4b80f, "ath9k_cmn_init_crypto" },
	{ 0xaddc925f, "ieee80211_queue_work" },
	{ 0x1e16bf1e, "dev_set_drvdata" },
	{ 0xc04d60f3, "led_classdev_register" },
	{ 0xb7b035a4, "ath9k_hw_btcoex_enable" },
	{ 0x35b90a60, "ath9k_hw_wait" },
	{ 0x3ce210c, "ath9k_cmn_get_hw_crypto_keytype" },
	{ 0x4c5fb2a4, "ath9k_hw_stopdmarecv" },
	{ 0x7f7212a5, "ath_key_delete" },
	{ 0x2e8487e7, "ath9k_cmn_update_txpow" },
	{ 0x1637ff0f, "_raw_spin_lock_bh" },
	{ 0x456fe090, "ieee80211_beacon_get_tim" },
	{ 0xedbe57ef, "ath9k_hw_gpio_get" },
	{ 0xe133860a, "ath_regd_init" },
	{ 0x88bfa7e, "cancel_work_sync" },
	{ 0x2b5621ed, "usb_kill_urb" },
	{ 0x8b7fe311, "kmemdup" },
	{ 0xa87be223, "ath9k_cmn_get_curchannel" },
	{ 0x8bff8e61, "ieee80211_unregister_hw" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xfb0e29f, "init_timer_key" },
	{ 0xfb5f846a, "cancel_delayed_work_sync" },
	{ 0xa7f6f440, "mutex_unlock" },
	{ 0x48d5ff93, "ieee80211_iterate_active_interfaces_atomic" },
	{ 0x67623767, "ath9k_hw_setrxfilter" },
	{ 0x1ea2153c, "ath9k_hw_get_txq_props" },
	{ 0xde207ca, "ath9k_hw_releasetxqueue" },
	{ 0xa914d916, "ath9k_hw_reset_tsf" },
	{ 0xef713ab8, "debugfs_create_file" },
	{ 0xcbd84c93, "wiphy_rfkill_start_polling" },
	{ 0x91715312, "sprintf" },
	{ 0x7d11c268, "jiffies" },
	{ 0x224ef58a, "skb_trim" },
	{ 0xa3a5dfad, "ieee80211_stop_queues" },
	{ 0xa0b3c13d, "usb_unanchor_urb" },
	{ 0x2eed15d2, "ieee80211_tx_status" },
	{ 0x24e5acfe, "ath_printk" },
	{ 0x6395be94, "__init_waitqueue_head" },
	{ 0xa759d756, "ath9k_hw_setopmode" },
	{ 0x6d0aba34, "wait_for_completion" },
	{ 0x2b6cb0c1, "ath9k_hw_disable" },
	{ 0xd5f2172f, "del_timer_sync" },
	{ 0x3c80c06c, "kstrtoull" },
	{ 0xb3111324, "ath9k_hw_resettxqueue" },
	{ 0xd5800c7b, "ath9k_hw_gettsf64" },
	{ 0x8567b1c3, "default_llseek" },
	{ 0x6c40974d, "dev_err" },
	{ 0x8f64aa4, "_raw_spin_unlock_irqrestore" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0x1837e804, "usb_deregister" },
	{ 0xf80d781b, "__mutex_init" },
	{ 0x27e1a049, "printk" },
	{ 0x33f0fba3, "ath9k_hw_set_sta_beacon_timers" },
	{ 0xdd48fdad, "ath9k_hw_set_tsfadjust" },
	{ 0x1cad3570, "ieee80211_wake_queues" },
	{ 0xfaef0ed, "__tasklet_schedule" },
	{ 0x601a2f9d, "ath9k_hw_btcoex_disable" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0x6d293d78, "ath9k_hw_getrxfilter" },
	{ 0xa092c754, "ath9k_hw_ani_monitor" },
	{ 0xb4390f9a, "mcount" },
	{ 0x4b4e8da0, "usb_control_msg" },
	{ 0x4e2481d5, "ath_is_world_regd" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0xb295640e, "ieee80211_rx" },
	{ 0xed9bef6, "skb_push" },
	{ 0xf2516109, "mutex_lock" },
	{ 0x4c1182cb, "bitmap_scnprintf" },
	{ 0x9545af6d, "tasklet_init" },
	{ 0x8834396c, "mod_timer" },
	{ 0xec6df2fd, "skb_pull" },
	{ 0x8fd9096, "simple_open" },
	{ 0xb115990, "wiphy_rfkill_stop_polling" },
	{ 0xa3507a8d, "request_firmware_nowait" },
	{ 0x59275983, "ath9k_cmn_update_ichannel" },
	{ 0x2e8f465d, "ath9k_hw_write_associd" },
	{ 0xa333687c, "ieee80211_queue_delayed_work" },
	{ 0x1dc2191f, "dev_kfree_skb_any" },
	{ 0xf11543ff, "find_first_zero_bit" },
	{ 0x21f2974b, "ath_reg_notifier_apply" },
	{ 0x252ec960, "wiphy_to_ieee80211_hw" },
	{ 0x82072614, "tasklet_kill" },
	{ 0x1ae9d6f, "ath9k_hw_init_btcoex_hw" },
	{ 0x55d40dd9, "ieee80211_stop_tx_ba_cb_irqsafe" },
	{ 0x54e9a89, "skb_queue_tail" },
	{ 0x177507ca, "ath9k_hw_beaconq_setup" },
	{ 0x4ff3c0b7, "_dev_info" },
	{ 0x62c22e01, "usb_submit_urb" },
	{ 0x731c7b88, "ath9k_hw_name" },
	{ 0x7e9c0688, "ath9k_hw_init_global_settings" },
	{ 0xf400a72a, "__alloc_skb" },
	{ 0x71ee2a1e, "usb_get_dev" },
	{ 0x8b68ce9f, "usb_kill_anchored_urbs" },
	{ 0xd2981357, "ath9k_cmn_count_streams" },
	{ 0x752104a5, "ath9k_hw_settsf64" },
	{ 0xba63339c, "_raw_spin_unlock_bh" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x3f74a1cc, "wiphy_rfkill_set_hw_state" },
	{ 0xe0d81039, "compat_dependency_symbol" },
	{ 0x3bd1b1f6, "msecs_to_jiffies" },
	{ 0x8c9813d5, "usb_bulk_msg" },
	{ 0x3b727767, "usb_put_dev" },
	{ 0x4b5814ef, "kmalloc_order_trace" },
	{ 0xb604e62a, "kfree_skb" },
	{ 0x32c5fc02, "ath9k_hw_beaconinit" },
	{ 0x75a1d63f, "ieee80211_find_sta" },
	{ 0x6a227c1a, "ieee80211_get_buffered_bc" },
	{ 0x93165b0, "ath9k_hw_btcoex_bt_stomp" },
	{ 0xce459a0d, "ath9k_hw_setrxabort" },
	{ 0x24f41ee7, "kmem_cache_alloc_trace" },
	{ 0xd52bf1ce, "_raw_spin_lock" },
	{ 0xbf3aef1d, "ath_hw_setbssidmask" },
	{ 0x9327f5ce, "_raw_spin_lock_irqsave" },
	{ 0xf59eadf3, "ath9k_cmn_padpos" },
	{ 0x60f93543, "ath9k_hw_phy_disable" },
	{ 0x1f5f7b2, "ieee80211_get_hdrlen_from_skb" },
	{ 0xbcc1b4bc, "ath9k_hw_setpower" },
	{ 0xf764e497, "__ieee80211_create_tpt_led_trigger" },
	{ 0x5b9d3295, "ieee80211_register_hw" },
	{ 0x539bd8d6, "led_classdev_unregister" },
	{ 0xf2a766a9, "ath9k_hw_btcoex_set_weight" },
	{ 0x37a0cba, "kfree" },
	{ 0x1453c016, "regulatory_hint" },
	{ 0x236c8c64, "memcpy" },
	{ 0xc824a023, "ath9k_hw_setmcastfilter" },
	{ 0x734c0839, "ieee80211_start_tx_ba_session" },
	{ 0xca0052af, "ieee80211_alloc_hw" },
	{ 0x175c1601, "ath9k_hw_startpcureceive" },
	{ 0x96079b2c, "ath9k_hw_setuptxqueue" },
	{ 0xa1b4eb92, "usb_register_driver" },
	{ 0x91c221f7, "ath9k_hw_reset" },
	{ 0x759bbfe6, "ieee80211_free_hw" },
	{ 0x4cbbd171, "__bitmap_weight" },
	{ 0x724a360c, "skb_dequeue" },
	{ 0xb54df66c, "usb_ifnum_to_if" },
	{ 0x4b06d2e7, "complete" },
	{ 0x50720c5f, "snprintf" },
	{ 0xa3a5be95, "memmove" },
	{ 0xb71cfb8d, "ath9k_hw_btcoex_init_3wire" },
	{ 0x52f9a1e4, "ath_key_config" },
	{ 0xd80245f6, "skb_put" },
	{ 0x53f6ffbc, "wait_for_completion_timeout" },
	{ 0x4f6b400b, "_copy_from_user" },
	{ 0xc3fe87c8, "param_ops_uint" },
	{ 0x7ccb4b8e, "ath9k_hw_reset_calvalid" },
	{ 0x1b19af65, "dev_get_drvdata" },
	{ 0x2e5c2b65, "usb_free_urb" },
	{ 0x90a0fe4c, "release_firmware" },
	{ 0x4df75d23, "ieee80211_start_tx_ba_cb_irqsafe" },
	{ 0x992d0e1b, "usb_anchor_urb" },
	{ 0xc797d467, "usb_alloc_urb" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=ath9k_hw,ath9k_common,mac80211,ath,cfg80211,compat";

MODULE_ALIAS("usb:v0CF3p9271d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0CF3p1006d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0846p9030d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07D1p3A10d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3327d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3328d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3346d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3348d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3349d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3350d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v04CAp4605d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v040Dp3801d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0CF3pB003d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v057Cp8403d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0CF3p7015d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v1668p1200d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0CF3p7010d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0846p9018d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v083ApA704d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0411p017Fd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v04DAp3904d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0CF3p20FFd*dc*dsc*dp*ic*isc*ip*");

MODULE_INFO(srcversion, "17E2C5152EB52480A880F7F");
