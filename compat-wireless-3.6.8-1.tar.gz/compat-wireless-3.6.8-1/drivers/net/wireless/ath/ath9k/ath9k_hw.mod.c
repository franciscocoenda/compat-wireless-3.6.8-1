#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x8495e121, "module_layout" },
	{ 0xc6d08280, "kmalloc_caches" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x24e5acfe, "ath_printk" },
	{ 0xde0bdcff, "memset" },
	{ 0xb4390f9a, "mcount" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0xb44b7ea8, "ath_hw_get_listen_time" },
	{ 0x53358ce3, "ath_regd_get_band_ctl" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xb9249d16, "cpu_possible_mask" },
	{ 0xe0d81039, "compat_dependency_symbol" },
	{ 0xab68d9bc, "ath_hw_cycle_counters_update" },
	{ 0x24f41ee7, "kmem_cache_alloc_trace" },
	{ 0xbf3aef1d, "ath_hw_setbssidmask" },
	{ 0x37a0cba, "kfree" },
	{ 0x236c8c64, "memcpy" },
	{ 0x4cbbd171, "__bitmap_weight" },
	{ 0x50720c5f, "snprintf" },
	{ 0x9e7d6bd0, "__udelay" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=ath,compat";


MODULE_INFO(srcversion, "DF7207DC072C74A19EE6073");
